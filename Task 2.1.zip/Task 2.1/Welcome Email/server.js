require("dotenv").config();
const sgMail = require("@sendgrid/mail");

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const path = require("path");
const express = require("express");
const app = express();

const sendEmail = require("./utils/sendEmail");

app.use(express.urlencoded({ extended: false }));
app.use("/public", express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");

app.get("/", (req, res) => {
	res.render("contact");
});

app.post("/sendemail", (req, res) => {
	const { email } = req.body;
	const from = "cableties2001@gmail.com";
	const subject = "Wow, an email";
	const text = "Thanks for signing up for me to email you";

	sendEmail(email, from, subject, text);
});

app.listen(5000, () => console.log("Server running on port 5000"));

import React, { useState } from "react";
import "./style.css";

function Email() {
	const [contact, setContact] = useState({
		email: "",
	});

	const handleChange = (event) => {
		const { name, value } = event.target;
		setContact((preValue) => {
			return {
				...preValue,
				[name]: value,
			};
		});
	};

	const handleClick = async () => {
		await fetch("http://localhost:5000/sendEmail", {
			method: "post",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				email: contact.email,
			}),
		})
			.then((response) => response.json())
			.then((data) => JSON.parse(data))
			.catch((Err) => {
				console.log("Error: " + Err);
			});
	};

	return (
		<div>
			<div class="subscribe-box">
				<div class="row">
					<div class="column large">
						<div class="subscribe-text">SIGN UP FOR DAILY INSIDER</div>
					</div>
					<div class="column medium">
						<input
							type="email"
							class="form-control"
							name="email"
							placeholder="Email"
							onChange={handleChange}
							value={contact.email}
							required="required"
						/>
					</div>
					<div class="column small">
						<button type="submit" onClick={handleClick}>
							Subscribe
						</button>
					</div>
				</div>
			</div>
		</div>
	);
}
export default Email;

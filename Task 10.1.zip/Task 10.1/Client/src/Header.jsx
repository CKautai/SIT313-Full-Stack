import React from "react";
import "./style.css";
import { faker } from "@faker-js/faker";
function Header() {
	return (
		<div>
			<div className="row header">
				<div className="column medium">
					<h2>DEV@Deakin</h2>
				</div>
				<div className="column large">
					<div className="searchBox">
						<div className="row">
							<img
								src="https://www.svgrepo.com/show/14071/search.svg"
								alt="search"
							></img>
							<p>Search</p>
						</div>
					</div>
				</div>
				<div className="column small">
					<h2>Post</h2>
				</div>
				<div className="column small">
					<h2>Login</h2>
				</div>
			</div>
			<div className="row">
				<img className="coverImage" src={faker.image.city()} alt="random"></img>
			</div>
		</div>
	);
}
export default Header;

require("dotenv").config();
const sgMail = require("@sendgrid/mail");

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const sendEmail = require("./utils/sendEmail");
const https = require("https");
const cors = require("cors");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));
app.use("/public", express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");

app.get("/", (req, res) => {
	res.render("contact");
});

app.post("/sendEmail", (req, res) => {
	const email = req.body.email;

	const from = "cableties2001@gmail.com";
	const subject = "Wow, an email";
	const text = "Thanks for signing up for me to email you";

	sendEmail(email, from, subject, text);
});

app.listen(5000, () => console.log("Server running on port 5000"));

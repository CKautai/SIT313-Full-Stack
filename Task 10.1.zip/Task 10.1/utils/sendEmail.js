require("dotenv").config();
const sgMail = require("@sendgrid/mail");
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const sendEmail = (to, from, subject, text) => {
	const msg = {
		to,
		from,
		subject,
		text,
	};

	sgMail.send(msg, function (err, result) {
		if (err) {
			console.log("Message not sent " + err);
		} else {
			console.log("Message sent");
		}
	});
};

module.exports = sendEmail;

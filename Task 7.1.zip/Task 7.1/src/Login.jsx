import React, { useState } from "react";
import Input from "./Input";
import { Link } from "react-router-dom";
import "./Login.css";
import {
	signInWithGooglePopup,
	createUserDocFromAuth,
	signinAuthUserWithEmailAndPassword,
} from "./utils/firebase";

const Login = (props) => {
	const logGoogleUser = async () => {
		const { user } = await signInWithGooglePopup();
		// eslint-disable-next-line
		const userDocRef = await createUserDocFromAuth(user);
	};

	const [contact, setContact] = useState({
		email: "",
		password: "",
	});

	const { email, password } = contact;
	const handleChange = (event) => {
		const { name, value } = event.target;
		setContact((preValue) => {
			return {
				...preValue,
				[name]: value,
			};
		});
	};

	const handleSubmit = async (event) => {
		event.preventDefault();
		try {
			const response = await signinAuthUserWithEmailAndPassword(
				email,
				password
			);
			console.log(response);
			props.auth(true);
		} catch (error) {
			console.log("error in login", error.message);
		}
	};

	return (
		<div className="login-style">
			<div className="input-box">
				<label for="email">Email:</label>
				<Input
					name="email"
					type="email"
					placeholder="email"
					onChange={handleChange}
					value={contact.username}
				/>
			</div>
			<div className="input-box">
				<label for="password">Password:</label>
				<Input
					name="password"
					type="password"
					placeholder="password"
					onChange={handleChange}
					value={contact.password}
				/>
			</div>

			<div className="input-box">
				<button className="login" onClick={handleSubmit}>
					Log in
				</button>
			</div>

			<div className="input-box">
				<button className="login" onClick={logGoogleUser}>
					Log in with Google
				</button>
			</div>

			<Link className="signup-title" to="/signup">
				Sign up instead
			</Link>
		</div>
	);
};
export default Login;

import React, { useState } from "react";
import Input from "./Input";
import { Link } from "react-router-dom";
import "./Signup.css";
import {
	createAuthUserWithEmailAndPassword,
	createUserDocFromAuth,
} from "./utils/firebase";

const Signup = (props) => {
	const [contact, setContact] = useState({
		displayName: "",
		email: "",
		password: "",
		confirmPassword: "",
	});

	const { displayName, email, password, confirmPassword } = contact;

	console.log(contact);

	const handleChange = (event) => {
		const { name, value } = event.target;
		setContact((preValue) => {
			return {
				...preValue,
				[name]: value,
			};
		});
	};

	const handleSubmit = async (event) => {
		event.preventDefault();
		if (password !== confirmPassword) {
			alert("Passwords do no match");
			return;
		}
		try {
			const { user } = await createAuthUserWithEmailAndPassword(
				email,
				password
			);
			await createUserDocFromAuth(user, { displayName });
		} catch (error) {
			console.log("error in creating user", error.message);
		}
	};

	return (
		<div className="login-style">
			<h3 className="signup-title">Create a DEV@Deakin Account</h3>
			<div className="input-box">
				<label for="displayName">Display Name:</label>
				<Input
					name="displayName"
					type="text"
					placeholder="Display Name"
					onChange={handleChange}
					value={contact.displayName}
				/>
			</div>
			<div className="input-box">
				<label for="email">Email</label>
				<Input
					name="email"
					type="email"
					placeholder="email"
					onChange={handleChange}
					value={contact.email}
				/>
			</div>
			<div className="input-box">
				<label for="password">Password</label>
				<Input
					name="password"
					type="password"
					placeholder="password"
					onChange={handleChange}
					value={contact.password}
				/>
			</div>
			<div className="input-box">
				<label for="confirmPassword">Confirm Password</label>
				<Input
					name="confirmPassword"
					type="password"
					placeholder="Confirm password"
					onChange={handleChange}
					value={contact.confirmPassword}
				/>
			</div>

			<div className="input-box">
				<button className="login" onClick={handleSubmit}>
					Create
				</button>
			</div>

			<Link className="signup-title" to="/login">
				Login
			</Link>
		</div>
	);
};
export default Signup;


import React from "react"
function AboutPage ()
{
    return <div>
    <h1> This is Deakin's website. </h1>
    </div>
}

export default AboutPage
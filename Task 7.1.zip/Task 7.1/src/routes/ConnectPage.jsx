import React from "react";
function ConnectPage()
{
    return <div>
    <h1> Contact us </h1>
    <p>
    Melbourne Burwood Campus
    <br></br>
    Call
    +61 3 9244 6100
    <br></br>
    8.30am 5pm, Monday to Friday
    </p>
    </div>
}
export default ConnectPage
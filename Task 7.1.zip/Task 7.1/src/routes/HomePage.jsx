import React from "react";
import Articles from "../Articles";
import Tutorials from "../Tutorials";
import Email from "../Email";

function HomePage() {
	return (
		<div>
			<Articles />
			<Tutorials />
			<Email />
		</div>
	);
}
export default HomePage;

import { initializeApp } from "firebase/app";
import {
	getAuth,
	signInWithPopup,
	GoogleAuthProvider,
	createUserWithEmailAndPassword,
	signInWithEmailAndPassword,
	onAuthStateChanged,
} from "firebase/auth";
import { getFirestore, doc, getDoc, setDoc } from "firebase/firestore";

// Your web app's Firebase configuration

const firebaseConfig = {
	apiKey: "",

	authDomain: "",

	projectId: "",

	storageBucket: "",

	messagingSenderId: "",

	appId: "",
};

// Initialize Firebase
// eslint-disable-next-line
const firebaseapp = initializeApp(firebaseConfig);

const provider = new GoogleAuthProvider();
provider.setCustomParameters({
	prompt: "select_account",
});

export const auth = getAuth();
export const signInWithGooglePopup = () => signInWithPopup(auth, provider);
export const db = getFirestore();
export const user = getAuth().currentUser;

export const createUserDocFromAuth = async (
	userAuth,
	addionalInformation = {}
) => {
	if (!userAuth.email) return;
	const userDocRef = doc(db, "users", userAuth.uid);

	const userSnapshot = await getDoc(userDocRef);

	if (!userSnapshot.exists()) {
		const { displayName, email } = userAuth;
		const createdAt = new Date();

		try {
			await setDoc(userDocRef, {
				displayName,
				email,
				createdAt,
				...addionalInformation,
			});
		} catch (error) {
			console.log("error in creating ", error.message);
		}
	}
	return userDocRef;
};
export const createAuthUserWithEmailAndPassword = async (email, password) => {
	if (!email || !password) return;
	return await createUserWithEmailAndPassword(auth, email, password);
};

export const signinAuthUserWithEmailAndPassword = async (email, password) => {
	if (!email || !password) return;
	return await signInWithEmailAndPassword(auth, email, password);
};
export const checkAuth = async () => {
	onAuthStateChanged(auth, (user) => {
		if (user) {
			return true;
		} else {
			return false;
		}
	});
};

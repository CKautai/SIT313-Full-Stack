import React from "react";
import "./style.css";

function Email() {
	return (
		<div>
			<div class="subscribe-box">
				<form action="/sendemail" method="POST">
					<div class="row">
						<div class="column large">
							<div class="subscribe-text">SIGN UP FOR DAILY INSIDER</div>
						</div>
						<div class="column medium">
							<input
								type="email"
								class="form-control"
								name="email"
								placeholder="Email"
								required="required"
							/>
						</div>
						<div class="column small">
							<button type="submit">Subscribe</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	);
}
export default Email;

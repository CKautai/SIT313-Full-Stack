import "./App.css";
import React from "react";
import Header from "./Header";
import "./Header.css";
import Articles from "./Articles";
import Tutorials from "./Tutorials";
import Email from "./Email";
import Footer from "./Footer";
function App() {
	return (
		<div>
			<Header />
			<Articles />
			<Tutorials />
			<Email />
			<Footer />
		</div>
	);
}

export default App;
